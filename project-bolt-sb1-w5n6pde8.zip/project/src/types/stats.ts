import { LucideIcon } from 'lucide-react';

export interface StatCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  change: number;
}