# Digital Signage Player Downloads

Ce dossier contient les fichiers d'installation du lecteur d'affichage dynamique.

- `digital-signage-player-setup.exe` - Installateur Windows du lecteur